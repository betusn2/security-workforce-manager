-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: trolley.proxy.rlwy.net    Database: railway
-- ------------------------------------------------------
-- Server version	9.4.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT (uuid()),
  `employee_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cin` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsapp_number` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` enum('agent','supervisor','admin','user') COLLATE utf8mb4_unicode_ci DEFAULT 'agent',
  `profile_photo` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `facial_vector` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `facial_descriptor` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `facial_vector_updated_at` datetime DEFAULT NULL,
  `address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `date_of_birth` date DEFAULT NULL,
  `hire_date` date DEFAULT NULL,
  `status` enum('active','inactive','suspended') COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `last_login` datetime DEFAULT NULL,
  `notification_preferences` json DEFAULT NULL,
  `refresh_token` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `height` int DEFAULT NULL,
  `weight` int DEFAULT NULL,
  `diploma` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `diploma_level` enum('cap','bac','bac+2','bac+3','bac+5','autre') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `security_card` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `security_card_expiry` date DEFAULT NULL,
  `experience_years` int DEFAULT '0',
  `specializations` json DEFAULT NULL,
  `languages` json DEFAULT NULL,
  `current_latitude` decimal(10,8) DEFAULT NULL,
  `current_longitude` decimal(11,8) DEFAULT NULL,
  `last_location_update` datetime DEFAULT NULL,
  `rating` decimal(3,2) DEFAULT '0.00',
  `total_ratings` int DEFAULT '0',
  `punctuality_score` int DEFAULT '100',
  `reliability_score` int DEFAULT '100',
  `professionalism_score` int DEFAULT '100',
  `overall_score` int DEFAULT '0',
  `emergency_contact` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emergency_phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_card_number` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `social_security_number` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank_details` json DEFAULT NULL,
  `supervisor_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `authorized_devices` json DEFAULT NULL,
  `last_check_in_location` json DEFAULT NULL,
  `created_by_type` enum('admin','supervisor','self_registration') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'admin',
  `created_by_user_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_temporary` tinyint(1) DEFAULT '0',
  `validated_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `validated_at` datetime DEFAULT NULL,
  `last_liveness_check` datetime DEFAULT NULL,
  `fraud_score` int DEFAULT '0',
  `device_fingerprints` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `employee_id` (`employee_id`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_users_email` (`email`),
  KEY `idx_users_employee_id` (`employee_id`),
  KEY `idx_users_cin` (`cin`),
  KEY `idx_users_role` (`role`),
  KEY `idx_users_status` (`status`),
  KEY `supervisor_id` (`supervisor_id`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`supervisor_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('0c85e590-bc6c-4372-bf25-1f7bd688c3fe','ADMIN001',NULL,'Admin','System','admin@securityguard.com','$2a$12$4Z7KUcSXQtV4szEzn5tLyuwLV3nKBtlE9oJcknjVvu0EUlUGyD4.G','+33600000000',NULL,'admin',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'active','2026-03-10 22:55:22',NULL,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjBjODVlNTkwLWJjNmMtNDM3Mi1iZjI1LTFmN2JkNjg4YzNmZSIsInR5cGUiOiJyZWZyZXNoIiwiaWF0IjoxNzczMTgzMzIyLCJleHAiOjE3NzU3NzUzMjJ9.UprW8qMQhzTH5h3h95bBLsgWwh16X8hLCSD4Cy9y2_Q',NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,9.99,0,100,100,100,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'admin',NULL,0,NULL,NULL,NULL,0,NULL,'2026-02-21 13:50:18','2026-03-10 22:55:22',NULL),('289031b6-1cce-11f1-b60d-a2aa0f1c5791','ADMIN002',NULL,'Admin','System2','admin2@securityguard.com','$2a$12$4Z7KUcSXQtV4szEzn5tLyuwLV3nKBtlE9oJcknjVvu0EUlUGyD4.G',NULL,NULL,'admin',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'active','2026-03-10 22:46:10',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0.00,0,100,100,100,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'admin',NULL,0,NULL,NULL,NULL,0,NULL,'2026-03-10 22:11:59','2026-03-10 22:55:11',NULL),('28903733-1cce-11f1-b60d-a2aa0f1c5791','ADMIN003',NULL,'Admin','System3','admin3@securityguard.com','$2a$12$4Z7KUcSXQtV4szEzn5tLyuwLV3nKBtlE9oJcknjVvu0EUlUGyD4.G',NULL,NULL,'admin',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0.00,0,100,100,100,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'admin',NULL,0,NULL,NULL,NULL,0,NULL,'2026-03-10 22:11:59','2026-03-10 22:11:59',NULL),('289038ee-1cce-11f1-b60d-a2aa0f1c5791','ADMIN004',NULL,'Admin','System4','admin4@securityguard.com','$2a$12$4Z7KUcSXQtV4szEzn5tLyuwLV3nKBtlE9oJcknjVvu0EUlUGyD4.G',NULL,NULL,'admin',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0.00,0,100,100,100,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'admin',NULL,0,NULL,NULL,NULL,0,NULL,'2026-03-10 22:11:59','2026-03-10 22:11:59',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-10 22:58:22
