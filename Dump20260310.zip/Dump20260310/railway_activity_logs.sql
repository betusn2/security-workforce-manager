-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: trolley.proxy.rlwy.net    Database: railway
-- ------------------------------------------------------
-- Server version	9.4.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity_logs`
--

DROP TABLE IF EXISTS `activity_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_logs` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT (uuid()),
  `user_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `action` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `old_values` json DEFAULT NULL,
  `new_values` json DEFAULT NULL,
  `ip_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `device_info` json DEFAULT NULL,
  `location` json DEFAULT NULL,
  `status` enum('success','failure','warning') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'success',
  `error_message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `metadata` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_activity_logs_user_id` (`user_id`),
  KEY `idx_activity_logs_action` (`action`),
  KEY `idx_activity_logs_entity_type` (`entity_type`),
  KEY `idx_activity_logs_created_at` (`created_at`),
  CONSTRAINT `activity_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_logs`
--

LOCK TABLES `activity_logs` WRITE;
/*!40000 ALTER TABLE `activity_logs` DISABLE KEYS */;
INSERT INTO `activity_logs` VALUES ('07e73679-6bf8-489c-bd3a-d38bf472406b','289031b6-1cce-11f1-b60d-a2aa0f1c5791','LOGIN','user','289031b6-1cce-11f1-b60d-a2aa0f1c5791','Connexion réussie',NULL,NULL,'196.119.124.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','{\"os\": \"Windows\", \"type\": \"desktop\", \"model\": null, \"browser\": \"Chrome\", \"version\": \"unknown\", \"platform\": \"desktop\", \"macAddress\": null}',NULL,'success',NULL,NULL,'2026-03-10 22:46:10',NULL),('0b024588-2e56-46d7-944e-3a0f35625dea','289031b6-1cce-11f1-b60d-a2aa0f1c5791','LOGOUT','user','289031b6-1cce-11f1-b60d-a2aa0f1c5791','Déconnexion',NULL,NULL,'196.119.124.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','{\"os\": \"Windows\", \"type\": \"desktop\", \"model\": null, \"browser\": \"Chrome\", \"version\": \"unknown\", \"platform\": \"desktop\", \"macAddress\": null}',NULL,'success',NULL,NULL,'2026-03-10 22:55:11',NULL),('11d4466b-df34-4fa2-a628-4d87a0e34699','0c85e590-bc6c-4372-bf25-1f7bd688c3fe','LOGIN','user','0c85e590-bc6c-4372-bf25-1f7bd688c3fe','Connexion réussie',NULL,NULL,'196.119.124.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','{\"os\": \"Windows\", \"type\": \"desktop\", \"model\": null, \"browser\": \"Chrome\", \"version\": \"unknown\", \"platform\": \"desktop\", \"macAddress\": null}',NULL,'success',NULL,NULL,'2026-03-10 22:55:23',NULL),('a6eaa3d6-3efc-4f86-85cc-c0022bb13a11',NULL,'database_reset','database',NULL,'Reset BDD : 22 tables vidées, 4 utilisateurs supprimés (admin conservé), 0 erreurs',NULL,'\"{}\"','10.17.180.76','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',NULL,NULL,'warning',NULL,NULL,'2026-03-10 22:44:07',NULL),('da9bc7b8-998a-4629-a5dc-7103eb6776c4','289031b6-1cce-11f1-b60d-a2aa0f1c5791','LOGOUT','user','289031b6-1cce-11f1-b60d-a2aa0f1c5791','Déconnexion',NULL,NULL,'196.119.124.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','{\"os\": \"Windows\", \"type\": \"desktop\", \"model\": null, \"browser\": \"Chrome\", \"version\": \"unknown\", \"platform\": \"desktop\", \"macAddress\": null}',NULL,'success',NULL,NULL,'2026-03-10 22:45:59',NULL),('e53086c8-e19e-4bb0-ba6f-30ebbcb2d8a6','289031b6-1cce-11f1-b60d-a2aa0f1c5791','CREATE','system',NULL,'CREATE system',NULL,NULL,'10.23.20.130','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',NULL,NULL,'success',NULL,NULL,'2026-03-10 22:46:00',NULL),('ea364919-b5a0-43a2-a653-77076f08a0aa','289031b6-1cce-11f1-b60d-a2aa0f1c5791','CREATE','system',NULL,'CREATE system',NULL,NULL,'10.16.159.47','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',NULL,NULL,'success',NULL,NULL,'2026-03-10 22:55:11',NULL);
/*!40000 ALTER TABLE `activity_logs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-10 22:56:35
